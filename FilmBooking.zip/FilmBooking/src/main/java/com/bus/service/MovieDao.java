	package com.bus.service;
	import java.time.LocalDate;
	import java.util.ArrayList;
	import java.util.Date;
	import java.util.List;
	import java.util.Optional;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.cache.annotation.Cacheable;
	import org.springframework.stereotype.Component;

	import com.bus.beans.CurrentDateOperation;
	import com.bus.beans.Customer;
	import com.bus.beans.MovieDetails;
	import com.bus.beans.OrderHistory;
	import com.bus.beans.Seat;

	@Component
	public class  MovieDao {
		
		@Autowired
		private MovieRepo repo;
				
		
		public int save1(MovieDetails movies_details) {
			
			repo.save(movies_details);
			return 1;
			
		}
		

				
		public List<MovieDetails> getAll(){
			List<MovieDetails> findAll = repo.findAll();
			return findAll;
		}
					
		
		public int updateDetail(MovieDetails movies_details) {
			repo.save(movies_details);
			return 1;
		}
		
	

		public void save(MovieDetails movies_deails) {
			// TODO Auto-generated method stub
			
		}
		
		
		
		

	}


